"""
preflight.py - environment verification. Run before ANYTHING else, on any machine.

The pipeline must never run degraded: a missing renderer means Fiona is blind, a
missing library means an agent silently stubs. Every check below must pass or the
pipeline HALTS with a named failure and the exact fix. No warnings, no fallbacks.

  python preflight.py            # human-readable report, exit 0/1
  from preflight import preflight; preflight()   # raises PreflightError
"""
import importlib.util
import json, shutil, subprocess, sys, tempfile
from pathlib import Path

HERE = Path(__file__).parent


class PreflightError(RuntimeError):
    pass


def _checks():
    yield ("python >= 3.9", sys.version_info >= (3, 9),
           f"found {sys.version.split()[0]} - install Python 3.9+")
    for mod, pipname in [("pptx", "python-pptx"), ("jsonschema", "jsonschema")]:
        ok = importlib.util.find_spec(mod) is not None
        yield (f"python module: {pipname}", ok, f"pip install {pipname}")
    node = shutil.which("node")
    yield ("node on PATH", bool(node), "install Node.js 18+")
    if node:
        ok = (HERE / "node_modules" / "pptxgenjs").exists()
        yield ("pptxgenjs installed", ok, f"cd {HERE} && npm install")
    for exe, pkg in [("soffice", "libreoffice"), ("pdftoppm", "poppler-utils")]:
        yield (f"{exe} on PATH (render/view)", bool(shutil.which(exe)),
               f"install {pkg} - REQUIRED: without it the pipeline cannot view decks "
               f"(ingest salvage + Fiona visual QA) and must not run")
    for f in ["orchestrator.py", "adapters.py", "assembler.js", "manifest.schema.json",
              "extract_pptx.py"]:
        yield (f"toolkit file: {f}", (HERE / f).exists(), f"restore {f} to {HERE}")
    for name in ["dylan-rules", "render-tufte-chart", "assess-graphical-excellence",
                 "aureconed", "george"]:
        p = HERE.parent / name / "SKILL.md"
        yield (f"skill: {name}", p.exists(),
               f"skill folder missing at {p.parent} - agents must not run without their skill")
    try:
        with tempfile.NamedTemporaryFile(dir=HERE, delete=True):
            pass
        writable = True
    except OSError:
        writable = False
    yield ("working dir writable", writable, f"{HERE} is not writable")


def _render_smoke():
    """Prove the view toolchain actually converts, not just exists on PATH."""
    if not (shutil.which("soffice") and shutil.which("pdftoppm")):
        return False, "toolchain missing (checked above)"
    try:
        import pptx
        from pptx.util import Inches
        with tempfile.TemporaryDirectory() as td:
            prs = pptx.Presentation()
            prs.slides.add_slide(prs.slide_layouts[6])
            p = Path(td) / "smoke.pptx"
            prs.save(p)
            subprocess.run(["soffice", "--headless", "--convert-to", "pdf",
                            "--outdir", td, str(p)], check=True, capture_output=True, timeout=120)
            subprocess.run(["pdftoppm", "-png", str(Path(td) / "smoke.pdf"),
                            str(Path(td) / "s")], check=True, capture_output=True, timeout=120)
            ok = any(Path(td).glob("s*.png"))
            return ok, "" if ok else "conversion produced no image"
    except Exception as e:
        return False, f"render smoke test failed: {e}"


def preflight(verbose=False):
    failures = []
    for name, ok, fix in _checks():
        if verbose:
            print(f"  [{'OK' if ok else 'FAIL'}] {name}" + ("" if ok else f"  -> {fix}"))
        if not ok:
            failures.append(f"{name}: {fix}")
    ok, why = _render_smoke()
    if verbose:
        print(f"  [{'OK' if ok else 'FAIL'}] render smoke test (pptx -> pdf -> png)"
              + ("" if ok else f"  -> {why}"))
    if not ok:
        failures.append(f"render smoke test: {why}")
    if failures:
        raise PreflightError(
            "PREFLIGHT FAILED - the pipeline must not run degraded. Fix and re-run:\n  - "
            + "\n  - ".join(failures))
    return True


if __name__ == "__main__":
    try:
        preflight(verbose=True)
        print("\npreflight: ALL CHECKS PASSED")
    except PreflightError as e:
        print(f"\n{e}")
        sys.exit(1)

"""
extract_pptx.py - self-contained deck ingest, no external skill required.

Dumps an existing .pptx to JSON so Anna (or any model) can ingest it in ANY
environment - Claude, Copilot CLI, plain terminal. This replaces the dependency
on the Claude-only `pptx` skill for the READ path. Requires python-pptx.

  python extract_pptx.py input.pptx [out.json] [--render out_dir] [--assets out_dir]

--assets exports every embedded picture to files (slideN_picM.ext) and records
them per slide, and pulls readable series data out of native charts - the raw
material for the salvage pass (carry pictures verbatim; rebuild charts native).

Output per slide: index, layout name, title, all text (with placeholder role),
tables as row arrays, chart inventory (type + series names), picture/shape
inventory, and speaker notes. --render additionally rasterises slides to PNG
via LibreOffice + pdftoppm when available (for visual ingest), and degrades
gracefully when not.
"""
import json, sys, shutil, subprocess
from pathlib import Path

def extract(path, assets_dir=None):
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    prs = Presentation(path)
    deck = {"path": str(path), "slide_count": len(prs.slides),
            "size_in": [round(prs.slide_width/914400, 3), round(prs.slide_height/914400, 3)],
            "slides": []}
    if assets_dir:
        Path(assets_dir).mkdir(parents=True, exist_ok=True)
    for i, slide in enumerate(prs.slides, 1):
        s = {"index": i, "layout": slide.slide_layout.name, "title": None,
             "texts": [], "tables": [], "charts": [], "pictures": 0,
             "picture_assets": [], "shapes": 0, "notes": None}
        for shp in slide.shapes:
            s["shapes"] += 1
            if shp.has_text_frame and shp.text_frame.text.strip():
                role = "title" if shp == slide.shapes.title else \
                       (shp.placeholder_format.type.name.lower()
                        if shp.is_placeholder and shp.placeholder_format.type else "body")
                txt = shp.text_frame.text.strip()
                s["texts"].append({"role": role, "text": txt})
                if role == "title":
                    s["title"] = txt
            if shp.has_table:
                s["tables"].append([[c.text.strip() for c in r.cells] for r in shp.table.rows])
            if getattr(shp, "has_chart", False) and shp.has_chart:
                ch = shp.chart
                chart = {"type": str(ch.chart_type), "series": []}
                try:
                    cats = [str(c) for c in ch.plots[0].categories] if ch.plots else []
                    for sr in (ch.plots[0].series if ch.plots else []):
                        chart["series"].append({"name": sr.name,
                            "points": [{"label": c, "value": v} for c, v in zip(cats, sr.values)]})
                except Exception:
                    chart["series"] = [{"name": sr.name, "points": None}
                                       for sr in (ch.plots[0].series if ch.plots else [])]
                s["charts"].append(chart)
            if shp.shape_type == MSO_SHAPE_TYPE.PICTURE:
                s["pictures"] += 1
                if assets_dir:
                    img = shp.image
                    fn = Path(assets_dir) / f"slide{i}_pic{s['pictures']}.{img.ext}"
                    fn.write_bytes(img.blob)
                    s["picture_assets"].append({"path": str(fn),
                        "size_in": [round(shp.width/914400, 2), round(shp.height/914400, 2)]})
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
            s["notes"] = slide.notes_slide.notes_text_frame.text.strip()
        if s["title"] is None and s["texts"]:
            # decks built from text boxes (e.g. PptxGenJS) have no title placeholder;
            # take the topmost text shape as the title
            tops = [(shp.top or 0, shp.text_frame.text.strip()) for shp in slide.shapes
                    if shp.has_text_frame and shp.text_frame.text.strip()]
            if tops:
                s["title"] = min(tops)[1].split("\n")[0]
        deck["slides"].append(s)
    return deck

def render(path, out_dir):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    missing = [e for e in ("soffice", "pdftoppm") if not shutil.which(e)]
    if missing:
        raise SystemExit(f"HALT: --render requires {', '.join(missing)}. Install them or run "
                         "the pipeline's preflight.py - never ingest a deck you cannot view.")
    try:
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf",
                        "--outdir", str(out), str(path)], check=True, capture_output=True, timeout=180)
        pdf = out / (Path(path).stem + ".pdf")
        subprocess.run(["pdftoppm", "-png", "-r", "110", str(pdf), str(out / "slide")],
                       check=True, capture_output=True, timeout=180)
        images = sorted(str(p) for p in out.glob("slide-*.png"))
        if not images:
            raise SystemExit("HALT: render produced no images.")
        return images
    except SystemExit:
        raise
    except Exception as e:
        raise SystemExit(f"HALT: render failed ({e}).")

if __name__ == "__main__":
    argv = sys.argv[1:]
    def flagval(f):
        return argv[argv.index(f) + 1] if f in argv and argv.index(f) + 1 < len(argv) else None
    do_render, rdirf = "--render" in argv, flagval("--render")
    assets = flagval("--assets")
    pos = [a for j, a in enumerate(argv) if not a.startswith("--")
           and (j == 0 or argv[j-1] not in ("--render", "--assets"))]
    src = Path(pos[0])
    out = Path(pos[1]) if len(pos) > 1 else src.with_suffix(".extracted.json")
    deck = extract(src, assets_dir=assets)
    if do_render:
        deck["rendered_images"] = render(src, rdirf or str(src.parent / "ingest_render"))
    out.write_text(json.dumps(deck, indent=2))
    print(f"extracted {deck['slide_count']} slides -> {out}"
          + (f"  ({len(deck.get('rendered_images', []))} images)" if do_render else ""))

"""
extract_pptx.py - self-contained deck ingest, no external skill required.

Dumps an existing .pptx to JSON so Anna (or any model) can ingest it in ANY
environment - Claude, Copilot CLI, plain terminal. This replaces the dependency
on the Claude-only `pptx` skill for the READ path. Requires python-pptx.

  python extract_pptx.py input.pptx [out.json] [--render out_dir]

Output per slide: index, layout name, title, all text (with placeholder role),
tables as row arrays, chart inventory (type + series names), picture/shape
inventory, and speaker notes. --render additionally rasterises slides to PNG
via LibreOffice + pdftoppm when available (for visual ingest), and degrades
gracefully when not.
"""
import json, sys, shutil, subprocess
from pathlib import Path

def extract(path):
    from pptx import Presentation
    from pptx.enum.shapes import MSO_SHAPE_TYPE
    prs = Presentation(path)
    deck = {"path": str(path), "slide_count": len(prs.slides),
            "size_in": [round(prs.slide_width/914400, 3), round(prs.slide_height/914400, 3)],
            "slides": []}
    for i, slide in enumerate(prs.slides, 1):
        s = {"index": i, "layout": slide.slide_layout.name, "title": None,
             "texts": [], "tables": [], "charts": [], "pictures": 0, "shapes": 0,
             "notes": None}
        for shp in slide.shapes:
            s["shapes"] += 1
            if shp.has_text_frame and shp.text_frame.text.strip():
                role = "title" if shp == slide.shapes.title else \
                       (shp.placeholder_format.type.name.lower()
                        if shp.is_placeholder and shp.placeholder_format.type else "body")
                txt = shp.text_frame.text.strip()
                s["texts"].append({"role": role, "text": txt})
                if role == "title":
                    s["title"] = txt
            if shp.has_table:
                s["tables"].append([[c.text.strip() for c in r.cells] for r in shp.table.rows])
            if getattr(shp, "has_chart", False) and shp.has_chart:
                ch = shp.chart
                s["charts"].append({"type": str(ch.chart_type),
                                    "series": [sr.name for sr in ch.plots[0].series] if ch.plots else []})
            if shp.shape_type == MSO_SHAPE_TYPE.PICTURE:
                s["pictures"] += 1
        if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
            s["notes"] = slide.notes_slide.notes_text_frame.text.strip()
        if s["title"] is None and s["texts"]:
            # decks built from text boxes (e.g. PptxGenJS) have no title placeholder;
            # take the topmost text shape as the title
            tops = [(shp.top or 0, shp.text_frame.text.strip()) for shp in slide.shapes
                    if shp.has_text_frame and shp.text_frame.text.strip()]
            if tops:
                s["title"] = min(tops)[1].split("\n")[0]
        deck["slides"].append(s)
    return deck

def render(path, out_dir):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    if not (shutil.which("soffice") and shutil.which("pdftoppm")):
        return []
    try:
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf",
                        "--outdir", str(out), str(path)], check=True, capture_output=True, timeout=180)
        pdf = out / (Path(path).stem + ".pdf")
        subprocess.run(["pdftoppm", "-png", "-r", "110", str(pdf), str(out / "slide")],
                       check=True, capture_output=True, timeout=180)
        return sorted(str(p) for p in out.glob("slide-*.png"))
    except Exception:
        return []

if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if a != "--render"]
    do_render = "--render" in sys.argv
    src = Path(args[0])
    out = Path(args[1]) if len(args) > 1 and not do_render else src.with_suffix(".extracted.json")
    deck = extract(src)
    if do_render:
        rdir = args[-1] if len(args) > 2 else str(src.parent / "ingest_render")
        deck["rendered_images"] = render(src, rdir)
    out.write_text(json.dumps(deck, indent=2))
    print(f"extracted {deck['slide_count']} slides -> {out}"
          + (f"  ({len(deck.get('rendered_images', []))} images)" if do_render else ""))
